# database information
MysqlInfo={
'DBUsrName':'root',
'DBPasswd':'password',
'DBName'  :'voting_app',
'DBHost'  :'localhost'		
}
