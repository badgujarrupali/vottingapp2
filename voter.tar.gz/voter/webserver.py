from app import app
#this is your run file
app.run(host='0.0.0.0',port=8000,debug=True,threaded=True)
